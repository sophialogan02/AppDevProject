package controllers;

public class User {
	
	public static String user = "";
	
}
